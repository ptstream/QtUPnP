var searchData=
[
  ['jarowinklerdistance',['jaroWinklerDistance',['../namespace_qt_u_pn_p.html#a6ae713dbe45e7e7a91f9149de4549df7',1,'QtUPnP']]]
];
