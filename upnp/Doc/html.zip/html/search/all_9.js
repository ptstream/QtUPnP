var searchData=
[
  ['jarodistance',['jaroDistance',['../helper_8cpp.html#a5960086b922fdb7f98bf73a2f3a892e7',1,'helper.cpp']]],
  ['jarowinklerdistance',['jaroWinklerDistance',['../namespace_qt_u_pn_p.html#a6ae713dbe45e7e7a91f9149de4549df7',1,'QtUPnP']]]
];
