var searchData=
[
  ['genre',['Genre',['../class_qt_u_pn_p_1_1_c_didl_item.html#ad746139b3e2cbfd69bc56ed4fc9b95f6a1a72a32e4298d0073cab7f2dafa067db',1,'QtUPnP::CDidlItem']]],
  ['get',['Get',['../class_qt_u_pn_p_1_1_c_plugin.html#a7142240f0a75580608eca6cf23629f94ad05c61f8a0f5b8ab732e4a90a9007c29',1,'QtUPnP::CPlugin']]]
];
