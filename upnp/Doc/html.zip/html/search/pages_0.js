var searchData=
[
  ['a_20framework_20to_20build_20easily_20an_20upnp_20control_20point_2e',['A framework to build easily an UPnP control point.',['../index.html',1,'']]]
];
